import datetime

def DateTime():
    return(datetime.datetime.now().strftime("%H:%M %d-%m-%Y"))

def Initialize():
    pass